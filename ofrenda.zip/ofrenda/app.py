"""Ofrenda: a local-first memory altar powered by an open-weight model (via Ollama).

Run:  python app.py   then open http://127.0.0.1:5000
"""
import os
import re

from flask import Flask, Response, jsonify, render_template, request, send_from_directory

import export
import llm
import store

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024  # photo uploads


@app.errorhandler(KeyError)
def _not_found(_e):
    return jsonify(error="Not found."), 404


@app.errorhandler(ValueError)
def _bad(e):
    return jsonify(error=str(e)), 400


@app.errorhandler(Exception)
def _boom(e):
    # HTTPExceptions (404 route, 413 too large...) keep their own status
    code = getattr(e, "code", 500)
    msg = "The model could not be reached or failed." if code == 500 else getattr(e, "description", "Error")
    if code == 500:
        app.logger.exception(e)
    return jsonify(error=msg), code


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/status")
def status():
    return jsonify(llm.status())


@app.get("/api/ofrendas")
def list_ofrendas():
    return jsonify(store.list_all())


@app.post("/api/ofrendas")
def create_ofrenda():
    d = request.get_json(silent=True) or {}
    return jsonify(store.create(d.get("name"), d.get("years"), d.get("relation"))), 201


@app.get("/api/ofrendas/<oid>")
def get_ofrenda(oid):
    return jsonify(store.get(oid))


@app.delete("/api/ofrendas/<oid>")
def delete_ofrenda(oid):
    store.delete(oid)
    return jsonify(ok=True)


@app.post("/api/ofrendas/<oid>/memories")
def add_memory(oid):
    d = request.get_json(silent=True) or {}
    return jsonify(store.add_memory(oid, d.get("kind"), d.get("text"))), 201


@app.delete("/api/ofrendas/<oid>/memories/<mid>")
def delete_memory(oid, mid):
    return jsonify(store.delete_memory(oid, mid))


@app.post("/api/ofrendas/<oid>/photo")
def upload_photo(oid):
    f = request.files.get("photo")
    if not f:
        raise ValueError("No photo uploaded.")
    return jsonify(store.save_photo(oid, f.filename, f.read()))


@app.get("/photos/<path:name>")
def photo(name):
    return send_from_directory(store.photo_path(name).parent, store.photo_path(name).name)


@app.post("/api/ofrendas/<oid>/remembrance")
def make_remembrance(oid):
    o = store.get(oid)
    text, mode = llm.generate_remembrance(o)
    return jsonify(text=text, mode=mode)


@app.put("/api/ofrendas/<oid>/remembrance")
def save_remembrance(oid):
    d = request.get_json(silent=True) or {}
    return jsonify(store.set_remembrance(oid, d.get("text")))


@app.post("/api/ofrendas/<oid>/ask")
def ask(oid):
    d = request.get_json(silent=True) or {}
    q = (d.get("question") or "").strip()[:500]
    if not q:
        raise ValueError("Ask something first.")
    return jsonify(llm.ask(store.get(oid), q))


@app.get("/api/ofrendas/<oid>/export")
def export_html(oid):
    o = store.get(oid)
    slug = re.sub(r"[^a-z0-9]+", "-", o["name"].lower()).strip("-") or "ofrenda"
    return Response(
        export.build_html(o),
        mimetype="text/html",
        headers={"Content-Disposition": f'attachment; filename="ofrenda-{slug}.html"'},
    )


if __name__ == "__main__":
    # 127.0.0.1 only: your memories are never exposed to the network.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
