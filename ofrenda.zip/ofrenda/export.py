"""Export an ofrenda as ONE self-contained HTML file.

No server, no JavaScript, no external fonts or images: open it in any browser,
in any year, offline. This is the "not locked inside a service" promise.
"""
import base64
import html
import mimetypes

import store

ICONS = {"story": "\U0001F4D6", "food": "\U0001F372", "song": "\U0001F3B5", "saying": "\U0001F4AC"}
LABELS = {"story": "Stories", "food": "Favorite foods", "song": "Songs", "saying": "Sayings"}

CSS = """
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top,#2a1638,#0d0814 70%);
color:#f3e9dc;font-family:Georgia,'Times New Roman',serif;line-height:1.7;min-height:100vh}
main{max-width:720px;margin:0 auto;padding:48px 20px 80px;text-align:center}
.candles{font-size:2rem;letter-spacing:.6rem;animation:flick 2.4s infinite alternate}
@keyframes flick{0%{opacity:.75;text-shadow:0 0 8px #ff9f1c}50%{opacity:1;text-shadow:0 0 22px #ffb703}100%{opacity:.85;text-shadow:0 0 12px #ff9f1c}}
.frame{width:200px;height:240px;margin:24px auto;border:4px solid #ff9f1c;border-radius:110px 110px 12px 12px;
overflow:hidden;box-shadow:0 0 40px #ff9f1c66;background:#1b1026;display:flex;align-items:center;justify-content:center;font-size:4rem}
.frame img{width:100%;height:100%;object-fit:cover}
h1{font-weight:400;font-size:2.4rem;margin:.2em 0 0;color:#ffb703}.years,.rel{opacity:.75;margin:0}
.remembrance{margin:36px 0;font-size:1.15rem;text-align:left;border-left:3px solid #ff9f1c;padding-left:18px}
h2{color:#ff9f1c;font-weight:400;border-bottom:1px solid #ff9f1c55;padding-bottom:6px;text-align:left;margin-top:40px}
ul{list-style:none;padding:0;text-align:left}li{margin:12px 0;padding:12px 16px;background:#ffffff0d;border-radius:10px}
footer{margin-top:60px;font-size:.85rem;opacity:.6}
"""


def _e(text):
    return html.escape(text or "", quote=True)


def _photo_uri(o):
    if not o.get("photo"):
        return None
    p = store.photo_path(o["photo"])
    if not p.exists():
        return None
    mime = mimetypes.guess_type(p.name)[0] or "image/jpeg"
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"


def build_html(o):
    uri = _photo_uri(o)
    frame = f'<img src="{uri}" alt="{_e(o["name"])}">' if uri else "\U0001F56F\ufe0f"
    rem = "".join(f"<p>{_e(line)}</p>" for line in o.get("remembrance", "").split("\n") if line.strip())
    sections = []
    for kind in ("story", "food", "song", "saying"):
        items = [m for m in o["memories"] if m["kind"] == kind]
        if items:
            lis = "".join(f"<li>{_e(m['text'])}</li>" for m in items)
            sections.append(f"<h2>{ICONS[kind]} {LABELS[kind]}</h2><ul>{lis}</ul>")
    sub = " &middot; ".join(x for x in (_e(o.get("years")), _e(o.get("relation"))) if x)
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ofrenda for {_e(o['name'])}</title><style>{CSS}</style></head>
<body><main>
<div class="candles">\U0001F56F\ufe0f \U0001F56F\ufe0f \U0001F56F\ufe0f</div>
<div class="frame">{frame}</div>
<h1>{_e(o['name'])}</h1><p class="years">{sub}</p>
<div class="remembrance">{rem}</div>
{''.join(sections)}
<footer>Made with Ofrenda, a local-first, open-source memory altar. This single file works offline, forever.</footer>
</main></body></html>"""
