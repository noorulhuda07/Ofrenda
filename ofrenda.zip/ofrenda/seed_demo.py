"""Create a fictional demo ofrenda (safe for screenshots and your demo video)."""
import store

o = store.create("Abuelita Rosa", "1941 - 2023", "grandmother")
demo = [
    ("story", "Every Sunday she woke before sunrise to make tamales, humming old boleros while the whole house smelled of corn and chili."),
    ("story", "She kept a jar of hard candies in her apron pocket and always pretended she had none until you hugged her."),
    ("food", "Tamales de rajas and champurrado with extra cinnamon"),
    ("song", "'Bésame Mucho' on her scratchy radio"),
    ("saying", "'El que come callado, come dos veces.'"),
    ("story", "When I failed my first exam she didn't say a word. She just set a plate in front of me and sat there until I laughed."),
]
for kind, text in demo:
    store.add_memory(o["id"], kind, text)
print("Demo ofrenda created:", o["id"])
