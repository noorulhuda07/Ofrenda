# 🕯️ Ofrenda: a memory altar that never leaves your machine

Hacktoberfest Open-Source AI Challenge, Week 4: **Ghost in the Machine**.

Ofrenda helps a family build a digital *ofrenda* (the altar of Día de los Muertos) for someone they miss.
You add stories, favorite foods, songs and sayings, in any language. A **local open-weight model (Gemma via Ollama)**
then helps you:

- ✍️ **Write a remembrance** using *only* the memories you shared (no invented facts).
- 🕯️ **Ask the Memory Keeper**: answers come only from your memories, cite them like `[2]`, and the model
  never speaks in the dead person's voice. If nobody shared the answer, it says so.
- 📦 **Export the altar as one HTML file** that opens offline in any browser, in any year.

Everything runs on `127.0.0.1`. No cloud, no account, no API key. If Ollama isn't running, the app
falls back to a small rule-based mode (clearly labelled) so it never breaks.

## Run it in VS Code (Windows)

1. Install [Ollama](https://ollama.com) and pull a model (Gemma recommended):
   ```powershell
   ollama pull gemma3:4b
   ollama list        # check the exact name you have
   ```
2. Open this folder in VS Code, then in the terminal:
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python seed_demo.py     # optional: creates a fictional demo altar
   python app.py
   ```
3. Open http://127.0.0.1:5000

Use a different model: `$env:OFRENDA_MODEL="gemma3:1b"` (PowerShell) before `python app.py`.
If your preferred model isn't installed, the app picks any installed Gemma, then any other chat model.
Slow laptop? Use a smaller model; the first request loads the model and can take a minute.

macOS/Linux: `source .venv/bin/activate`, `export OFRENDA_MODEL=...`.

## Tests

```powershell
python -m unittest discover -s tests -v
```

## Layout

```
app.py          Flask server + JSON API (binds to localhost only)
llm.py          Ollama client, grounded prompts, keyword retriever, offline fallback
store.py        JSON-file storage in ./data (atomic writes, validated ids)
export.py       One-file offline HTML export
templates/ static/   Vanilla JS UI, no build step, no external requests
seed_demo.py    Fictional demo data for screenshots/video
tests/          Unit tests (stdlib unittest)
```

## Privacy and safety choices

- Memories live in `./data` as plain JSON: readable, copyable, deletable.
- The model is told to use only supplied memories, to cite them, to refuse to impersonate the person,
  and to treat memory text as data (prompt-injection hygiene).
- UI renders text with `textContent`; the export HTML-escapes everything.

MIT licensed.
