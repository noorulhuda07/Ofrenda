import sys, tempfile, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import store, llm, export  # noqa: E402


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        store.DATA_DIR = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_create_and_memories(self):
        o = store.create("Rosa", "1941-2023", "grandmother")
        store.add_memory(o["id"], "food", "tamales")
        o = store.get(o["id"])
        self.assertEqual(len(o["memories"]), 1)
        store.delete_memory(o["id"], o["memories"][0]["id"])
        self.assertEqual(store.get(o["id"])["memories"], [])

    def test_validation(self):
        with self.assertRaises(ValueError):
            store.create("  ")
        o = store.create("Rosa")
        with self.assertRaises(ValueError):
            store.add_memory(o["id"], "nonsense", "x")
        with self.assertRaises(KeyError):
            store.get("../../etc/passwd")

    def test_retrieval_finds_relevant_memory(self):
        mems = [{"kind": "story", "text": "She loved fishing at the lake"},
                {"kind": "food", "text": "tamales every Sunday morning"}]
        top = llm.retrieve(mems, "what did she cook on Sunday? tamales")
        self.assertEqual(top[0][0], 2)

    def test_retrieval_telugu_tokens(self):
        mems = [{"kind": "story", "text": "అమ్మమ్మ ప్రతి ఆదివారం పులిహోర చేసేది"}]
        self.assertIn("పులిహోర", llm._tokens("పులిహోర ఎప్పుడు చేసేది?"))
        self.assertIn("పులిహోర", llm._tokens(mems[0]["text"]))

    def test_fallback_when_ollama_down(self):
        llm.HOST = "http://127.0.0.1:9"  # nothing listens here
        o = store.create("Rosa", "", "grandmother")
        store.add_memory(o["id"], "food", "tamales")
        o = store.get(o["id"])
        text, mode = llm.generate_remembrance(o)
        self.assertEqual(mode, llm.FALLBACK_MODE)
        self.assertIn("Rosa", text)
        r = llm.ask(o, "what food?")
        self.assertEqual(r["mode"], llm.FALLBACK_MODE)
        r = llm.ask(o, "xyzzy plugh")
        self.assertIn("No one has shared", r["answer"])

    def test_export_escapes_html(self):
        o = store.create("<script>alert(1)</script>")
        store.add_memory(o["id"], "story", "<img src=x onerror=alert(1)>")
        out = export.build_html(store.get(o["id"]))
        self.assertNotIn("<script>alert", out)
        self.assertNotIn("<img src=x", out)


if __name__ == "__main__":
    unittest.main()
