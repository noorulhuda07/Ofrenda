*This is a submission for the [Hacktoberfest Open-Source AI Challenge Week 4: Ghost in the Machine](https://dev.to/challenges/hacktoberfest-week4-2026-10-26)*

## What I Built

**Ofrenda** is a memory altar that never leaves your computer.

On Día de los Muertos, families build an *ofrenda* for the people they miss: a photo, a candle, their favorite food, their song. The idea is that someone is only truly gone when nobody says their name anymore. I read the "Ghost in the Machine" prompt as: *what is the ghost, and who gets to keep it?* My answer is that the ghost is a person's stories, and a family, not a company, should be the one keeping them.

You light a candle for someone, then add stories, foods, songs and sayings, in any language. A local open-weight model then does two jobs:

- **Writes a remembrance** from *only* what you shared. It is told never to invent names, places or events.
- **The Memory Keeper**: ask "what did she cook on Sundays?" and it answers from your memories, with citations like `[2]`. It speaks *about* the person and never in their voice. If nobody has shared the answer, it says: *"No one has shared a memory of that yet."* I did not want a chatbot pretending to be someone's grandmother. I wanted something that helps you remember, not something that fakes a séance.

When you're done, **export the altar as a single HTML file**: no server, no JavaScript, no fonts to download. It opens offline in any browser, in any year.

## Demo

<!-- TODO: paste your video link or embed here. Suggested 60-90s flow: seed_demo.py -> open the app -> add one real memory -> "Write with the local model" -> ask the Memory Keeper a question it CAN answer and one it CAN'T -> Export -> unplug Wi-Fi and open the exported file. -->

## Code

<!-- TODO: replace with your repo, e.g. {% embed https://github.com/YOUR_USERNAME/ofrenda %} -->

Stack: Python + Flask, vanilla JS (no build step), JSON files for storage, Ollama for local inference. Tests use only the standard library.

## How I Built It

- **Model:** an open-weight **Gemma** model served locally by **Ollama** (`gemma3:4b` by default; `OFRENDA_MODEL` swaps it, and the app auto-detects what you have installed).
- **Grounding over cleverness:** every memory is numbered and passed to the model with strict instructions: use only these, cite them, never impersonate, and treat memory text as data, not instructions. A small keyword retriever picks the most relevant memories for each question (it splits on whitespace, so it works for scripts like Telugu and Devanagari too, not just English).
- **Graceful ghosts:** if Ollama isn't running, the app drops to a labelled rule-based `offline-fallback` instead of failing, so the altar always opens.
- **Local-first by construction:** the server binds to `127.0.0.1`, storage is plain JSON in `./data` with atomic writes, and the UI makes zero external requests.
- **Safety details:** text is rendered with `textContent`, the exported HTML is escaped, IDs are validated against path traversal, and photo uploads are extension-checked and size-capped.

```
app.py   llm.py   store.py   export.py   static/   templates/   tests/   seed_demo.py
```

## Why Does Open Innovation Matter?

A grief archive is about the most private dataset a family has. Stories about a parent's last year, a grandmother's recipes, the thing a friend always said.

- **Privacy:** with an open-weight model running locally, those stories are never uploaded to a server we don't control, and never become someone else's training data.
- **It works with the lights (and the internet) off:** the model, the app and the exported altar all run offline.
- **Not locked inside a service that might disappear:** closed memorial apps shut down, change pricing, or change terms. Here the data is plain JSON, the model is a file on your disk, and the export is one HTML page. A family can still open it in twenty years.
- **Control over behavior:** because I own the model's instructions, I could enforce the rule that matters most emotionally: *never speak in the voice of the dead.* I could also tune it to cite sources and to refuse to guess, which is hard to guarantee with a hosted model whose behavior changes between versions.
- **Cost:** it costs nothing to run per question, which matters for something people might come back to every November.

## My Agent Session

<!-- TODO (optional): save your session with DevRelay and embed it with the agent_session tag, or link it. Only include this if you actually built part of the project with an agent. -->

## The Spirit of It

<!-- TODO: write ONE true moment. Add a real memory about someone you miss, run it through Ofrenda, and describe what the remembrance or the Memory Keeper's answer made you feel, or what a relative said when they read it. Keep it short and specific; judges weight writing quality most. Delete this section if you don't have a real moment. -->

## Prize Categories

<!-- Keep ONLY the ones that are true for your final project: -->
- **Best Use of Gemma**: the core model is Gemma, run locally through Ollama.
- **Best Use of GitHub Copilot**: <!-- keep only if you really used Copilot to build it, and say how -->
- **Best Use of Entire**: <!-- keep only if you share the agent sessions behind the project -->

<!-- Solo submission by YOUR_DEV_USERNAME (team ZENITH). -->
