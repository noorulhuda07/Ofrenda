// Ofrenda frontend: vanilla JS, no build step, no external requests.
const KINDS = { story: ["📖", "Story"], food: ["🍲", "Favorite food"], song: ["🎵", "Song"], saying: ["💬", "Saying"] };
const state = { list: [], current: null };
const $ = (s) => document.querySelector(s);

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid); // strings become text nodes (XSS-safe)
  return el;
}

async function api(path, opts = {}) {
  const init = { ...opts };
  if (opts.body && !(opts.body instanceof FormData)) {
    init.headers = { "Content-Type": "application/json" };
    init.body = JSON.stringify(opts.body);
  }
  const res = await fetch(path, init);
  let data = {};
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 3500);
}

// Run an async action, disable the button meanwhile, toast any error.
async function guard(btn, label, fn) {
  const old = btn.textContent;
  btn.disabled = true;
  if (label) btn.textContent = label;
  try { await fn(); } catch (e) { toast(e.message); }
  btn.disabled = false;
  btn.textContent = old;
}

async function loadStatus() {
  const p = $("#pill");
  try {
    const s = await api("/api/status");
    if (s.online) { p.className = "pill on"; p.textContent = `● local model: ${s.model}`; }
    else { p.className = "pill off"; p.textContent = "● Ollama not found: offline-fallback mode"; }
  } catch (_) { p.className = "pill off"; p.textContent = "● server unreachable"; }
}

async function loadList(selectId) {
  state.list = await api("/api/ofrendas");
  const ul = $("#list");
  ul.replaceChildren(...state.list.map((o) =>
    h("li", { class: o.id === (state.current && state.current.id) ? "active" : "", onclick: () => openOfrenda(o.id) },
      o.photo ? h("img", { src: `/photos/${o.photo}`, alt: "" }) : h("div", { class: "ph" }, "🕯️"),
      h("div", {}, o.name, h("small", {}, `${o.count} memories`)))));
  if (selectId) return openOfrenda(selectId);
  if (!state.current) state.list.length ? openOfrenda(state.list[0].id) : renderNewForm();
}

async function openOfrenda(id) {
  state.current = await api(`/api/ofrendas/${id}`);
  renderAltar();
  const ul = $("#list");
  [...ul.children].forEach((li, i) => li.classList.toggle("active", state.list[i].id === id));
}

function renderNewForm() {
  state.current = null;
  const name = h("input", { placeholder: "Abuelita Rosa", maxlength: 80 });
  const years = h("input", { placeholder: "1941 – 2023 (optional)", maxlength: 40 });
  const rel = h("input", { placeholder: "grandmother, friend, teacher… (optional)", maxlength: 80 });
  const btn = h("button", { class: "primary" }, "Light the candle");
  btn.addEventListener("click", () => guard(btn, "Lighting…", async () => {
    const o = await api("/api/ofrendas", { method: "POST", body: { name: name.value, years: years.value, relation: rel.value } });
    await loadList(o.id);
  }));
  $("#main").replaceChildren(h("div", { class: "card" },
    h("h2", {}, "Who are we remembering?"),
    h("label", {}, "Name"), name, h("label", {}, "Years"), years, h("label", {}, "Who were they to you?"), rel,
    h("div", { class: "row" }, btn)));
}

function renderAltar() {
  const o = state.current;
  const main = $("#main");

  // --- hero ---
  const file = h("input", { type: "file", accept: "image/*", style: "display:none" });
  file.addEventListener("change", async () => {
    if (!file.files[0]) return;
    const fd = new FormData(); fd.append("photo", file.files[0]);
    try { state.current = await api(`/api/ofrendas/${o.id}/photo`, { method: "POST", body: fd }); await loadList(o.id); }
    catch (e) { toast(e.message); }
  });
  const photoBtn = h("button", { onclick: () => file.click() }, "Add photo");
  const exportBtn = h("button", { onclick: () => (location.href = `/api/ofrendas/${o.id}/export`) }, "Export as one HTML file");
  const delBtn = h("button", { class: "danger" }, "Delete");
  delBtn.addEventListener("click", async () => {
    if (!confirm(`Delete the ofrenda for ${o.name}? This cannot be undone.`)) return;
    await api(`/api/ofrendas/${o.id}`, { method: "DELETE" });
    state.current = null; await loadList();
  });
  const hero = h("div", { class: "card hero" },
    h("div", { class: "frame" }, o.photo ? h("img", { src: `/photos/${o.photo}?t=${Date.now()}`, alt: o.name }) : "🕯️"),
    h("div", {}, h("h1", {}, o.name), h("p", {}, [o.years, o.relation].filter(Boolean).join(" · ")),
      h("div", { class: "row" }, photoBtn, exportBtn, delBtn, file)));

  // --- memories ---
  const memList = h("div");
  const drawMemories = () => memList.replaceChildren(...(state.current.memories.length
    ? state.current.memories.map((m, i) => h("div", { class: "mem" },
        h("span", { class: "n" }, `[${i + 1}]`), h("span", {}, KINDS[m.kind][0]), h("span", { class: "t" }, m.text),
        h("button", { title: "remove", onclick: async () => {
          state.current = await api(`/api/ofrendas/${o.id}/memories/${m.id}`, { method: "DELETE" }); drawMemories(); loadList();
        } }, "✕")))
    : [h("p", { class: "note" }, "Nothing here yet. Add the first thing you remember.")]));
  const kind = h("select", {}, Object.entries(KINDS).map(([k, [ic, lb]]) => h("option", { value: k }, `${ic} ${lb}`)));
  const text = h("textarea", { placeholder: "She hummed while she kneaded dough, and always saved the first tortilla for me…" });
  const addBtn = h("button", { class: "primary" }, "Add to the altar");
  addBtn.addEventListener("click", () => guard(addBtn, "Adding…", async () => {
    state.current = await api(`/api/ofrendas/${o.id}/memories`, { method: "POST", body: { kind: kind.value, text: text.value } });
    text.value = ""; drawMemories(); loadList();
  }));
  const memCard = h("div", { class: "card" }, h("h2", {}, "Memories"), memList,
    h("label", {}, "Add a memory (any language)"), h("div", { class: "row" }, h("div", {}, kind)), text, h("div", { class: "row" }, addBtn));
  drawMemories();

  // --- remembrance ---
  const rem = h("textarea", { style: "min-height:180px" }); rem.value = o.remembrance || "";
  const mode = h("p", { class: "note" }, "Written only from your memories. Edit freely before saving.");
  const genBtn = h("button", { class: "primary" }, "Write with the local model");
  genBtn.addEventListener("click", () => guard(genBtn, "Lighting the candle… (first run can take a minute)", async () => {
    const r = await api(`/api/ofrendas/${o.id}/remembrance`, { method: "POST" });
    rem.value = ""; mode.textContent = `Drafted by: ${r.mode}`;
    const words = r.text.split(/(\s+)/);
    for (const w of words) { rem.value += w; await new Promise((res) => setTimeout(res, 18)); } // slow "apparition" reveal
  }));
  const saveBtn = h("button", {}, "Save remembrance");
  saveBtn.addEventListener("click", () => guard(saveBtn, "Saving…", async () => {
    state.current = await api(`/api/ofrendas/${o.id}/remembrance`, { method: "PUT", body: { text: rem.value } });
    toast("Saved.");
  }));
  const remCard = h("div", { class: "card" }, h("h2", {}, "Remembrance"), rem, mode, h("div", { class: "row" }, genBtn, saveBtn));

  // --- ask the memory keeper ---
  const log = h("div");
  const q = h("input", { placeholder: "What did she cook on Sundays?" });
  const askBtn = h("button", { class: "primary" }, "Ask");
  const doAsk = () => guard(askBtn, "Listening…", async () => {
    const question = q.value.trim(); if (!question) return;
    log.append(h("div", { class: "bubble q" }, question)); q.value = "";
    const r = await api(`/api/ofrendas/${o.id}/ask`, { method: "POST", body: { question } });
    log.append(h("div", { class: "bubble a" }, r.answer,
      r.sources.length ? h("div", { class: "src" }, "From memories: ", r.sources.map((s) => `[${s.n}] ${KINDS[s.kind][0]} ${s.text.slice(0, 70)}…`).join("  ·  ")) : null,
      h("div", { class: "src" }, `mode: ${r.mode}`)));
  });
  askBtn.addEventListener("click", doAsk);
  q.addEventListener("keydown", (e) => { if (e.key === "Enter") doAsk(); });
  const askCard = h("div", { class: "card" }, h("h2", {}, "Ask the Memory Keeper"),
    h("p", { class: "note" }, "It answers only from the memories above, cites them, and never speaks in the voice of the person. If no one has shared the answer, it says so."),
    log, h("div", { class: "row" }, h("div", { class: "grow" }, q), askBtn));

  main.replaceChildren(hero, memCard, remCard, askCard);
}

$("#newBtn").addEventListener("click", renderNewForm);
loadStatus();
loadList().catch((e) => toast(e.message));
