"""Local-first storage for Ofrenda.

Everything lives in plain JSON files + image files inside ./data.
No database, no cloud, no account. Copy the folder and you've copied the altar.
"""
import json
import os
import re
import time
import uuid
from pathlib import Path

DATA_DIR = Path(os.environ.get("OFRENDA_DATA", Path(__file__).parent / "data"))
ID_RE = re.compile(r"^[0-9a-f]{12}$")
KINDS = ("story", "food", "song", "saying")
PHOTO_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
MAX_TEXT = 4000


def _dir(sub):
    d = Path(DATA_DIR) / sub
    d.mkdir(parents=True, exist_ok=True)
    return d


def _path(oid):
    if not isinstance(oid, str) or not ID_RE.match(oid):
        raise KeyError(oid)
    return _dir("ofrendas") / f"{oid}.json"


def _write(o):
    p = _path(o["id"])
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(o, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)  # atomic: a crash never leaves a half-written altar


def get(oid):
    p = _path(oid)
    if not p.exists():
        raise KeyError(oid)
    return json.loads(p.read_text(encoding="utf-8"))


def list_all():
    items = []
    for p in _dir("ofrendas").glob("*.json"):
        o = json.loads(p.read_text(encoding="utf-8"))
        items.append(
            {
                "id": o["id"],
                "name": o["name"],
                "years": o.get("years", ""),
                "photo": o.get("photo"),
                "count": len(o.get("memories", [])),
                "created": o.get("created", 0),
            }
        )
    return sorted(items, key=lambda i: i["created"])


def create(name, years="", relation=""):
    name = (name or "").strip()
    if not name:
        raise ValueError("A name is needed to light the first candle.")
    o = {
        "id": uuid.uuid4().hex[:12],
        "name": name[:80],
        "years": (years or "").strip()[:40],
        "relation": (relation or "").strip()[:80],
        "created": time.time(),
        "photo": None,
        "memories": [],
        "remembrance": "",
    }
    _write(o)
    return o


def add_memory(oid, kind, text):
    o = get(oid)
    text = (text or "").strip()
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {', '.join(KINDS)}")
    if not text:
        raise ValueError("A memory can't be empty.")
    o["memories"].append(
        {"id": uuid.uuid4().hex[:8], "kind": kind, "text": text[:MAX_TEXT], "added": time.time()}
    )
    _write(o)
    return o


def delete_memory(oid, mid):
    o = get(oid)
    o["memories"] = [m for m in o["memories"] if m["id"] != mid]
    _write(o)
    return o


def set_remembrance(oid, text):
    o = get(oid)
    o["remembrance"] = (text or "").strip()[:MAX_TEXT]
    _write(o)
    return o


def save_photo(oid, filename, data):
    o = get(oid)
    ext = Path(filename or "").suffix.lower()
    if ext not in PHOTO_EXT:
        raise ValueError("Photo must be png, jpg, webp or gif.")
    pdir = _dir("photos")
    if o.get("photo"):
        (pdir / Path(o["photo"]).name).unlink(missing_ok=True)
    name = f"{oid}{ext}"
    (pdir / name).write_bytes(data)
    o["photo"] = name
    _write(o)
    return o


def photo_path(name):
    return _dir("photos") / Path(name).name


def delete(oid):
    o = get(oid)
    if o.get("photo"):
        photo_path(o["photo"]).unlink(missing_ok=True)
    _path(oid).unlink(missing_ok=True)
